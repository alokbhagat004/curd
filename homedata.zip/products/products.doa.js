var mongooes = require('mongooes')
var productSchema = require('./products.model')

productSchema.static = {
	create : function(data,cb){
		var product = new this(data);
		product.save(cb)
	},
	getRow : function(query,cb){
		this.findOne(query,cb)
	},
	getResult : function(query,cb){
		this.find(query,cb)
	},
	update : function(query,updateData,cb){
		 this.findOneAndUpdate(query,{$set: updateData},{new: true},cb);
	},
	delete : function(query,cb){
		this.findOneDelete(query,cb)
	}
}

var porductModel = mongooes.model('Products',productSchema)
module.exports = porductModel