var Products = require('./product.doa')

exports.addProduct = function(){
	var errorCode = 0;
    var errorMessage = "";
	var product = {
		name 			:	req.body.name,
		category		:	req.body.category,
		subCategory 	:	req.body.subCategory,
		specification	:	req.body.specification,
		isAffiliate		:	req.body.isAffiliate,
		isFeatured		:	req.body.isFeatured,
		affiliate		:	req.body.affiliate,
		longDiscription	:	req.body.longDiscription,
		shortDiscription:	req.body.shortDiscription
	}
	
	Products.addProduct(product,function(err,product){
		if(!err){
			errorCode = 1;
            errorMessage = "Created Sucessfully";
		}else{
			 errorCode = 0;
             errorMessage = err;
		}
		var response  = {
            "Error" : {
                "ErrorCode" : errorCode,
                "ErrorMessage" : errorMessage
            }
        }
        res.json(response)
	})
}