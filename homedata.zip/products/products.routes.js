var product = require('./product.controller')
module.exports = function (router){
	router.post('./add-product', product.addProduct)
}